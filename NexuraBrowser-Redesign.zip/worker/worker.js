// Nexura Auth Worker — Firebase Auth ka proxy.
// Secrets (Cloudflare me set karo, repo me kabhi nahi):
//   FIREBASE_API_KEY  -> Firebase Web API key (google-services.json ke "current_key" se)
// Endpoints (sab POST, JSON body):
//   /auth/signup   {email, password}
//   /auth/login    {email, password}
//   /auth/refresh  {refreshToken}
//   /auth/reset    {email}
//   GET  /auth/google/start?challenge=...     -> Google login shuru
//   GET  /auth/google/callback                -> Google yahin wapas aata hai
//   POST /auth/google/exchange {code, verifier} -> app tokens leta hai
// Google ke liye extra secrets: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET

const IDT = "https://identitytoolkit.googleapis.com/v1/accounts";
const STS = "https://securetoken.googleapis.com/v1/token";

const MESSAGES = {
  EMAIL_EXISTS: "Ye email pehle se registered hai",
  EMAIL_NOT_FOUND: "Is email se account nahi mila",
  INVALID_PASSWORD: "Password galat hai",
  INVALID_LOGIN_CREDENTIALS: "Email ya password galat hai",
  USER_DISABLED: "Ye account disable kar diya gaya hai",
  INVALID_EMAIL: "Email sahi nahi hai",
  MISSING_PASSWORD: "Password likhna zaroori hai",
  TOO_MANY_ATTEMPTS_TRY_LATER: "Bahut zyada koshish, thodi der baad try karo",
  OPERATION_NOT_ALLOWED: "Firebase me Email/Password sign-in on nahi hai",
  TOKEN_EXPIRED: "Session expire ho gaya, dobara login karo",
  USER_NOT_FOUND: "Account nahi mila, dobara login karo",
  INVALID_REFRESH_TOKEN: "Session expire ho gaya, dobara login karo",
  INVALID_CODE: "Google login adhura reh gaya, dobara try karo",
  CODE_EXPIRED: "Google login ka time nikal gaya, dobara try karo",
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

const fail = (code, status = 400) => {
  const key = String(code || "").split(" ")[0];
  if (key.startsWith("WEAK_PASSWORD")) return json({ ok: false, code: key, error: "Password kam se kam 6 characters ka rakho" }, status);
  return json({ ok: false, code: key, error: MESSAGES[key] || "Kuch galat hua, dobara try karo" }, status);
};

async function firebase(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}


// ---------- Google login helpers ----------
const b64u = (buf) => {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));

// Short-lived code ko AES-GCM se lock karte hain (koi database nahi chahiye)
async function codeKey(env) {
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("nexura-code:" + env.GOOGLE_CLIENT_SECRET));
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function seal(env, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await codeKey(env), new TextEncoder().encode(JSON.stringify(obj)));
  const out = new Uint8Array(12 + ct.byteLength);
  out.set(iv);
  out.set(new Uint8Array(ct), 12);
  return b64u(out);
}
async function unseal(env, s) {
  const buf = unb64u(s);
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: buf.slice(0, 12) }, await codeKey(env), buf.slice(12));
  return JSON.parse(new TextDecoder().decode(pt));
}

// Browser se app me wapas bhejne wala page (nexura://auth?...)
const appPage = (params, title) => {
  const link = "nexura://auth?" + new URLSearchParams(params).toString();
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nexura</title></head>
<body style="font-family:sans-serif;text-align:center;padding:56px 24px;background:#0F0D1A;color:#F5F3FF">
<h2>${title}</h2>
<p><a href="${link}" style="display:inline-block;margin-top:18px;padding:14px 28px;border-radius:999px;background:#8B5CF6;color:#fff;text-decoration:none;font-weight:bold">Nexura app kholo</a></p>
<script>location.href=${JSON.stringify(link)}</script></body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
};
const validChallenge = (c) => /^[A-Za-z0-9_-]{43}$/.test(c || "");

async function googleStart(url, env) {
  const challenge = url.searchParams.get("challenge");
  if (!validChallenge(challenge)) return appPage({ error: "Bad request" }, "Kuch galat hua");
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) return appPage({ error: "Server setup adhura hai" }, "Server setup adhura hai");
  const g = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  g.search = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID,
    redirect_uri: url.origin + "/auth/google/callback",
    response_type: "code",
    scope: "openid email profile",
    state: challenge,
    prompt: "select_account",
  }).toString();
  return Response.redirect(g.toString(), 302);
}

async function googleCallback(url, env) {
  const code = url.searchParams.get("code");
  const challenge = url.searchParams.get("state");
  if (url.searchParams.get("error") || !code || !validChallenge(challenge)) {
    return appPage({ error: "Google login cancel ho gaya" }, "Login cancel ho gaya");
  }
  const tokRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: env.GOOGLE_CLIENT_ID,
      client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: url.origin + "/auth/google/callback",
      grant_type: "authorization_code",
    }).toString(),
  });
  const tok = await tokRes.json().catch(() => ({}));
  if (!tokRes.ok || !tok.id_token) return appPage({ error: "Google se login nahi ho paya" }, "Login fail ho gaya");

  const r = await firebase(`${IDT}:signInWithIdp?key=${encodeURIComponent(env.FIREBASE_API_KEY)}`, {
    postBody: `id_token=${encodeURIComponent(tok.id_token)}&providerId=google.com`,
    requestUri: "http://localhost",
    returnSecureToken: true,
    returnIdpCredential: true,
  });
  if (!r.ok || !r.data.refreshToken) {
    const msg = r.data?.needConfirmation || r.data?.emailExists
      ? "Is email se pehle password account bana hai, usi se login karo"
      : "Google se login nahi ho paya";
    return appPage({ error: msg }, "Login fail ho gaya");
  }
  const sealed = await seal(env, {
    rt: r.data.refreshToken,
    email: r.data.email || "",
    uid: r.data.localId || "",
    ch: challenge,
    exp: Date.now() + 2 * 60 * 1000,
  });
  return appPage({ code: sealed }, "Login ho gaya");
}

const validEmail = (e) => typeof e === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length <= 254;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") return json({ ok: true, service: "nexura-auth" });
    if (request.method === "GET" && url.pathname === "/auth/google/start") return googleStart(url, env);
    if (request.method === "GET" && url.pathname === "/auth/google/callback") {
      if (!env.FIREBASE_API_KEY || !env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
        return appPage({ error: "Server setup adhura hai" }, "Server setup adhura hai");
      }
      return googleCallback(url, env);
    }
    if (request.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);
    if (!env.FIREBASE_API_KEY) return json({ ok: false, error: "Server setup adhura hai" }, 500);

    let body;
    try { body = await request.json(); } catch { return json({ ok: false, error: "Bad request" }, 400); }
    const key = `?key=${encodeURIComponent(env.FIREBASE_API_KEY)}`;

    switch (url.pathname) {
      case "/auth/signup":
      case "/auth/login": {
        const { email, password } = body;
        if (!validEmail(email)) return fail("INVALID_EMAIL");
        if (typeof password !== "string" || !password) return fail("MISSING_PASSWORD");
        const endpoint = url.pathname === "/auth/signup" ? "signUp" : "signInWithPassword";
        const r = await firebase(`${IDT}:${endpoint}${key}`, { email, password, returnSecureToken: true });
        if (!r.ok) return fail(r.data?.error?.message);
        return json({
          ok: true,
          uid: r.data.localId,
          email: r.data.email,
          idToken: r.data.idToken,
          refreshToken: r.data.refreshToken,
          expiresIn: Number(r.data.expiresIn) || 3600,
        });
      }
      case "/auth/refresh": {
        if (typeof body.refreshToken !== "string" || !body.refreshToken) return fail("INVALID_REFRESH_TOKEN");
        const res = await fetch(`${STS}${key}`, {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(body.refreshToken)}`,
        });
        const d = await res.json().catch(() => ({}));
        if (!res.ok) return fail(d?.error?.message, 401);
        return json({
          ok: true,
          uid: d.user_id,
          idToken: d.id_token,
          refreshToken: d.refresh_token,
          expiresIn: Number(d.expires_in) || 3600,
        });
      }
      case "/auth/reset": {
        if (!validEmail(body.email)) return fail("INVALID_EMAIL");
        const r = await firebase(`${IDT}:sendOobCode${key}`, { requestType: "PASSWORD_RESET", email: body.email });
        // email enumeration se bachne ke liye EMAIL_NOT_FOUND ko bhi success dikhate hain
        if (!r.ok && r.data?.error?.message !== "EMAIL_NOT_FOUND") return fail(r.data?.error?.message);
        return json({ ok: true });
      }
      case "/auth/google/exchange": {
        if (!env.GOOGLE_CLIENT_SECRET) return json({ ok: false, error: "Server setup adhura hai" }, 500);
        const { code, verifier } = body;
        if (typeof code !== "string" || typeof verifier !== "string" || verifier.length < 43 || verifier.length > 128) return fail("INVALID_CODE");
        let p;
        try { p = await unseal(env, code); } catch { return fail("INVALID_CODE"); }
        if (Date.now() > p.exp) return fail("CODE_EXPIRED");
        const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
        if (b64u(digest) !== p.ch) return fail("INVALID_CODE");
        return json({ ok: true, uid: p.uid, email: p.email, refreshToken: p.rt });
      }
      default:
        return json({ ok: false, error: "Not found" }, 404);
    }
  },
};

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "in.nexura.browser"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    defaultConfig {
        applicationId = "in.nexura.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        // Worker URL: GitHub Actions variable AUTH_API_URL se aata hai (secret nahi, sirf URL hai)
        val authUrl = System.getenv("AUTH_API_URL") ?: (project.findProperty("AUTH_API_URL") as String? ?: "")
        buildConfigField("String", "AUTH_API_URL", "\"$authUrl\"")
    }
    buildFeatures {
        buildConfig = true
    }
}

package `in`.nexura.browser

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class DlItem(
    val id: Long, val title: String, val status: Int, val total: Long, val done: Long,
    val mime: String, val src: String?, val time: Long
)

/** Full-screen live downloads manager. Polls DownloadManager and updates progress, speed and ETA. */
class DownloadsScreen(private val act: MainActivity) : ContextWrapper(act) {

    private class RowHolder(val sub: TextView, val sub2: TextView?, val fill: View?)

    val view: FrameLayout = FrameLayout(act)

    private val pal: Palette get() = act.pal
    private val accent: Int get() = act.accent
    private val dm = act.getSystemService(DOWNLOAD_SERVICE) as DownloadManager
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var filter = 0
    private var query = ""
    private var sort = 0
    private var items: List<DlItem> = emptyList()
    private var signature = ""
    private val speeds = HashMap<Long, Float>()
    private val lastBytes = HashMap<Long, Long>()
    private val lastTs = HashMap<Long, Long>()
    private val holders = HashMap<Long, RowHolder>()
    private var summaryView: TextView? = null
    private val cats = listOf("All", "Images", "Videos", "Audio", "APK", "Docs", "Archives", "Other")

    private val list: LinearLayout
    private val chipsRow: LinearLayout
    private val searchBox: LinearLayout
    private val searchInput: EditText

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            poll()
            handler.postDelayed(this, 800)
        }
    }

    init {
        view.setBackgroundColor(pal.bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar
        val rip = withAlpha(pal.text, 0.12f)
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(8), dp(8), dp(8), dp(4))
        bar.addView(iconButton(R.drawable.ic_back, pal.text, rip) { act.closeDownloads() })
        val title = label("Downloads", 22f, pal.text, 2)
        bar.addView(title, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        bar.addView(iconButton(R.drawable.ic_search, pal.text, rip) { toggleSearch() })
        bar.addView(iconButton(R.drawable.ic_sort, pal.text, rip) { sortSheet() })
        bar.addView(iconButton(R.drawable.ic_more, pal.text, rip) { moreSheet() })
        col.addView(bar, lp(MATCH, WRAP))

        // search box (hidden until the search icon is tapped)
        searchBox = LinearLayout(this)
        searchBox.gravity = Gravity.CENTER_VERTICAL
        searchBox.background = rounded(pal.surface, 24f, pal.outline, 1)
        searchBox.setPadding(dp(16), 0, dp(12), 0)
        searchBox.visibility = View.GONE
        searchBox.addView(iconView(R.drawable.ic_search, pal.textSub), lp(dp(20), dp(20)))
        searchInput = EditText(this)
        searchInput.hint = "Search downloads"
        searchInput.background = null
        searchInput.isSingleLine = true
        searchInput.textSize = 14f
        searchInput.setTextColor(pal.text)
        searchInput.setHintTextColor(pal.textSub)
        searchInput.setPadding(dp(10), 0, dp(6), 0)
        searchInput.inputType = InputType.TYPE_CLASS_TEXT
        searchInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                render(true)
            }
        })
        searchBox.addView(searchInput, lp(0, MATCH, 1f))
        col.addView(searchBox, lp(MATCH, dp(48)).apply { setMargins(dp(16), dp(4), dp(16), dp(4)) })

        // filter chips
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        chipsRow = LinearLayout(this)
        chipsRow.setPadding(dp(16), dp(8), dp(8), dp(8))
        hs.addView(chipsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        col.addView(hs, lp(MATCH, WRAP))
        buildChips()

        // list
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), dp(0), dp(16), dp(28))
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, lp(MATCH, 0, 1f))
    }

    fun start() {
        running = true
        poll()
        handler.postDelayed(ticker, 800)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(ticker)
    }

    // ───────────────────────── data ─────────────────────────

    private fun isActive(s: Int) =
        s == DownloadManager.STATUS_RUNNING || s == DownloadManager.STATUS_PENDING || s == DownloadManager.STATUS_PAUSED

    private fun catOf(title: String, mime: String): Int {
        val ext = title.substringAfterLast('.', "").lowercase()
        return when {
            mime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg") -> 1
            mime.startsWith("video/") || ext in setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv") -> 2
            mime.startsWith("audio/") || ext in setOf("mp3", "m4a", "wav", "flac", "ogg", "aac", "opus") -> 3
            ext == "apk" || mime == "application/vnd.android.package-archive" -> 4
            ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub", "rtf") ||
                mime.startsWith("text/") || mime == "application/pdf" -> 5
            ext in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz") || mime.contains("zip") -> 6
            else -> 7
        }
    }

    private fun catColor(c: Int): Int = when (c) {
        1 -> Brand.GREEN
        2 -> Brand.PURPLE
        3 -> Brand.YELLOW
        4 -> Brand.RED
        5 -> Brand.GREEN
        6 -> Brand.YELLOW
        else -> Brand.PURPLE
    }

    private fun catIcon(c: Int): Int = when (c) {
        1 -> R.drawable.ic_image
        2 -> R.drawable.ic_video
        3 -> R.drawable.ic_audio
        4 -> R.drawable.ic_apk
        5 -> R.drawable.ic_doc
        6 -> R.drawable.ic_archive
        else -> R.drawable.ic_file
    }

    private fun poll() {
        val now = System.currentTimeMillis()
        val out = ArrayList<DlItem>()
        try {
            val c = dm.query(DownloadManager.Query())
            if (c != null) {
                c.use {
                    val iId = it.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                    val iTitle = it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                    val iStatus = it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                    val iTotal = it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    val iDone = it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                    val iMime = it.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
                    val iUri = it.getColumnIndexOrThrow(DownloadManager.COLUMN_URI)
                    val iTime = it.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
                    while (it.moveToNext()) {
                        val id = it.getLong(iId)
                        val status = it.getInt(iStatus)
                        val done = it.getLong(iDone)
                        out.add(
                            DlItem(
                                id, it.getString(iTitle) ?: "Download", status, it.getLong(iTotal), done,
                                it.getString(iMime) ?: "", it.getString(iUri), it.getLong(iTime)
                            )
                        )
                        if (status == DownloadManager.STATUS_RUNNING) {
                            val pb = lastBytes[id]
                            val pt = lastTs[id]
                            if (pb != null && pt != null && now > pt) {
                                val inst = (done - pb) * 1000f / (now - pt)
                                val old = speeds[id] ?: inst
                                speeds[id] = if (inst < 0f) old else old * 0.6f + inst * 0.4f
                            }
                            lastBytes[id] = done
                            lastTs[id] = now
                        } else {
                            speeds.remove(id)
                            lastBytes.remove(id)
                            lastTs.remove(id)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // keep the previous list
        }
        items = out
        render(false)
    }

    private fun visibleItems(): List<DlItem> {
        var l = items.filter { filter == 0 || catOf(it.title, it.mime) == filter }
        if (query.isNotEmpty()) l = l.filter { it.title.contains(query, true) }
        return when (sort) {
            1 -> l.sortedBy { it.id }
            2 -> l.sortedBy { it.title.lowercase() }
            3 -> l.sortedByDescending { if (it.total > 0) it.total else it.done }
            else -> l.sortedByDescending { it.id }
        }
    }

    // ───────────────────────── rendering ─────────────────────────

    private fun render(force: Boolean) {
        val vis = visibleItems()
        val sig = vis.joinToString(",") { "${it.id}:${it.status}" } + "|$filter|$query|$sort"
        if (force || sig != signature) {
            signature = sig
            rebuild(vis)
        }
        var total = 0f
        var n = 0
        for (item in vis) {
            if (!isActive(item.status)) continue
            holders[item.id]?.let { bindActive(it, item) }
            total += speeds[item.id] ?: 0f
            n++
        }
        summaryView?.text = if (total > 1f) "↓ ${fmtSpeed(total)} • $n active" else "$n active"
    }

    private fun rebuild(vis: List<DlItem>) {
        list.removeAllViews()
        holders.clear()
        summaryView = null
        if (vis.isEmpty()) {
            list.addView(emptyState(), lp(MATCH, WRAP))
            return
        }
        val active = vis.filter { isActive(it.status) }
        val failed = vis.filter { it.status == DownloadManager.STATUS_FAILED }
        val done = vis.filter { it.status == DownloadManager.STATUS_SUCCESSFUL }
        if (active.isNotEmpty()) {
            section("In progress", true)
            active.forEach { addRow(it) }
        }
        if (failed.isNotEmpty()) {
            section("Failed", false)
            failed.forEach { addRow(it) }
        }
        if (done.isNotEmpty()) {
            section("Completed", false)
            done.forEach { addRow(it) }
        }
    }

    private fun section(text: String, withSummary: Boolean) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(text, 14f, act.deepen(accent), 2), lp(0, WRAP, 1f))
        if (withSummary) {
            val s = label("", 12f, pal.textSub, 1)
            row.addView(s, lp(WRAP, WRAP))
            summaryView = s
        }
        list.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(14); bottomMargin = dp(2) })
    }

    private fun emptyState(): LinearLayout {
        val e = LinearLayout(this)
        e.orientation = LinearLayout.VERTICAL
        e.gravity = Gravity.CENTER
        e.setPadding(0, dp(72), 0, dp(24))
        e.addView(badge(R.drawable.ic_download, accent, 84), lp(dp(84), dp(84)))
        val noMatch = filter != 0 || query.isNotEmpty()
        e.addView(label(if (noMatch) "Nothing found" else "No downloads yet", 17f, pal.text, 2), lp(WRAP, WRAP).apply { topMargin = dp(16) })
        e.addView(
            label(if (noMatch) "Try another filter or search." else "Files you download will show up here.", 13f, pal.textSub),
            lp(WRAP, WRAP).apply { topMargin = dp(6) }
        )
        return e
    }

    private fun buildChips() {
        chipsRow.removeAllViews()
        cats.forEachIndexed { i, name ->
            val c = if (i == 0) accent else catColor(i)
            val sel = i == filter
            val chip = LinearLayout(this)
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(12), 0, dp(14), 0)
            chip.background = ripple(
                if (sel) withAlpha(c, 0.22f) else Color.TRANSPARENT, 20f, withAlpha(c, 0.2f),
                if (sel) c else pal.outline, 1
            )
            val icon = if (i == 0) R.drawable.ic_download else catIcon(i)
            chip.addView(iconView(icon, if (sel) act.deepen(c) else c), lp(dp(18), dp(18)))
            chip.addView(label(name, 13f, if (sel) pal.text else pal.textSub, 1), lp(WRAP, WRAP).apply { leftMargin = dp(6) })
            chip.isClickable = true
            chip.setOnClickListener {
                filter = i
                buildChips()
                render(true)
            }
            chipsRow.addView(chip, lp(WRAP, dp(38)).apply { rightMargin = dp(8) })
        }
    }

    private fun addRow(d: DlItem) {
        val cat = catOf(d.title, d.mime)
        val color = catColor(cat)
        val active = isActive(d.status)
        val failed = d.status == DownloadManager.STATUS_FAILED
        val ripc = withAlpha(pal.text, 0.12f)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = ripple(pal.surface, 20f, withAlpha(color, 0.15f), pal.outline, 1)
        card.setPadding(dp(14), dp(14), dp(8), dp(14))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(badge(catIcon(cat), color, 48), lp(dp(48), dp(48)))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        val title = label(d.title, 14.5f, pal.text, 1)
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.MIDDLE
        texts.addView(title)
        val subColor = if (failed) Brand.RED else if (active) act.deepen(accent) else pal.textSub
        val sub = label("", 12f, subColor, 1)
        sub.setPadding(0, dp(4), 0, 0)
        texts.addView(sub)
        var sub2: TextView? = null
        if (active) {
            val s2 = label("", 11.5f, pal.textSub)
            s2.setPadding(0, dp(2), 0, 0)
            texts.addView(s2)
            sub2 = s2
        }
        top.addView(texts, lp(0, WRAP, 1f).apply { leftMargin = dp(12); rightMargin = dp(4) })

        when {
            active -> top.addView(iconButton(R.drawable.ic_close, pal.textSub, ripc, sizeDp = 38, iconDp = 20) { cancel(d) })
            failed -> top.addView(iconButton(R.drawable.ic_refresh, Brand.RED, ripc, sizeDp = 38, iconDp = 20) { retry(d) })
            else -> top.addView(iconButton(R.drawable.ic_more, pal.textSub, ripc, sizeDp = 38, iconDp = 22) { itemSheet(d) })
        }
        card.addView(top, lp(MATCH, WRAP))

        var fill: View? = null
        if (active) {
            val track = FrameLayout(this)
            track.background = rounded(pal.outline, 3f)
            track.clipToOutline = true
            val f = View(this)
            f.pivotX = 0f
            f.scaleX = 0.02f
            f.background = when (d.status) {
                DownloadManager.STATUS_RUNNING -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, Brand.ALL)
                DownloadManager.STATUS_PAUSED -> rounded(Brand.YELLOW, 3f)
                else -> rounded(Brand.PURPLE, 3f)
            }
            track.addView(f, FrameLayout.LayoutParams(MATCH, MATCH))
            card.addView(track, lp(MATCH, dp(6)).apply { topMargin = dp(12); rightMargin = dp(6) })
            fill = f
        }

        if (active) {
            val h = RowHolder(sub, sub2, fill)
            holders[d.id] = h
            bindActive(h, d)
        } else if (failed) {
            sub.text = "Download failed • tap refresh to retry"
        } else {
            val bytes = if (d.total > 0) d.total else d.done
            val rel = DateUtils.getRelativeTimeSpanString(d.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
            sub.text = "${size(bytes)} • $rel"
            card.isClickable = true
            card.setOnClickListener { open(d) }
        }
        list.addView(card, lp(MATCH, WRAP).apply { topMargin = dp(10) })
    }

    private fun bindActive(h: RowHolder, d: DlItem) {
        val frac = if (d.total > 0) (d.done.toFloat() / d.total).coerceIn(0f, 1f) else 0f
        val sp = speeds[d.id] ?: 0f
        h.sub.text = when (d.status) {
            DownloadManager.STATUS_RUNNING -> {
                val pct = if (d.total > 0) "${(frac * 100).toInt()}%" else "…"
                val eta = if (d.total > 0 && sp > 1f) fmtEta(((d.total - d.done) / sp).toLong()) else "calculating…"
                "$pct • ${fmtSpeed(sp)} • $eta"
            }
            DownloadManager.STATUS_PAUSED -> "Paused • waiting for network"
            else -> "Waiting to start…"
        }
        h.sub2?.text = if (d.total > 0) "${size(d.done)} of ${size(d.total)}" else size(d.done)
        h.fill?.scaleX = if (d.total > 0) maxOf(frac, 0.02f) else 0.08f
    }

    // ───────────────────────── formatting ─────────────────────────

    private fun size(bytes: Long): String = Formatter.formatFileSize(this, bytes)
    private fun fmtSpeed(bps: Float): String = Formatter.formatFileSize(this, bps.toLong()) + "/s"
    private fun fmtEta(sec: Long): String = when {
        sec >= 3600 -> "${sec / 3600}h ${(sec % 3600) / 60}m left"
        sec >= 60 -> "${sec / 60}m ${sec % 60}s left"
        else -> "${maxOf(sec, 1)}s left"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ───────────────────────── actions ─────────────────────────

    private fun toggleSearch() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (searchBox.visibility == View.VISIBLE) {
            searchInput.setText("")
            searchBox.visibility = View.GONE
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            searchBox.visibility = View.VISIBLE
            searchInput.requestFocus()
            imm.showSoftInput(searchInput, 0)
        }
    }

    private fun cancel(d: DlItem) {
        dm.remove(d.id)
        toast("Download cancelled")
        poll()
    }

    private fun retry(d: DlItem) {
        val src = d.src
        if (src == null) {
            toast("Link not available")
            return
        }
        try {
            val req = DownloadManager.Request(Uri.parse(src)).setTitle(d.title).setDescription("Downloading with Nexura Browser")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            act.applyDest(req, d.title)
            dm.remove(d.id)
            dm.enqueue(req)
            toast("Retrying…")
        } catch (e: Exception) {
            toast("Retry failed: ${e.message}")
        }
        poll()
    }

    private fun open(d: DlItem) {
        try {
            val uri = dm.getUriForDownloadedFile(d.id) ?: throw IllegalStateException("missing")
            val mime = dm.getMimeTypeForDownloadedFile(d.id) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open this file")
        }
    }

    private fun share(d: DlItem) {
        try {
            val uri = dm.getUriForDownloadedFile(d.id) ?: throw IllegalStateException("missing")
            val mime = dm.getMimeTypeForDownloadedFile(d.id) ?: "*/*"
            val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share file"))
        } catch (e: Exception) {
            toast("Can't share this file")
        }
    }

    private fun copyLink(d: DlItem) {
        val src = d.src ?: return
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", src))
        toast("Link copied")
    }

    private fun itemSheet(d: DlItem) {
        val cat = catOf(d.title, d.mime)
        act.showSheet { body, dialog, _ ->
            val bytes = if (d.total > 0) d.total else d.done
            act.sheetHeader(body, catIcon(cat), catColor(cat), d.title, size(bytes))
            fun add(v: View) { body.addView(v, lp(MATCH, WRAP).apply { topMargin = dp(10) }) }
            add(act.settingRow(R.drawable.ic_open, Brand.GREEN, "Open", "View with another app", null) { dialog.dismiss(); open(d) })
            add(act.settingRow(R.drawable.ic_share, Brand.PURPLE, "Share", "Send this file", null) { dialog.dismiss(); share(d) })
            if (d.src != null) {
                add(act.settingRow(R.drawable.ic_copy, Brand.YELLOW, "Copy link", "Original download address", null) { dialog.dismiss(); copyLink(d) })
            }
            add(act.settingRow(R.drawable.ic_trash, Brand.RED, "Delete", "Removes the file from your phone", null) {
                dialog.dismiss()
                dm.remove(d.id)
                toast("Deleted")
                poll()
            })
        }
    }

    private fun sortSheet() {
        act.showSheet { body, dialog, _ ->
            act.sheetHeader(body, R.drawable.ic_sort, accent, "Sort by", null)
            val names = listOf("Newest first", "Oldest first", "Name (A–Z)", "Largest first")
            names.forEachIndexed { i, n ->
                val trailing = if (i == sort) iconView(R.drawable.ic_check, accent) else null
                body.addView(
                    act.settingRow(R.drawable.ic_sort, Brand.ALL[i % 4], n, if (i == sort) "Selected" else "Tap to apply", trailing) {
                        sort = i
                        dialog.dismiss()
                        render(true)
                    },
                    lp(MATCH, WRAP).apply { topMargin = dp(10) }
                )
            }
        }
    }

    private fun moreSheet() {
        act.showSheet { body, dialog, _ ->
            act.sheetHeader(body, R.drawable.ic_more, accent, "More", null)
            fun add(v: View) { body.addView(v, lp(MATCH, WRAP).apply { topMargin = dp(10) }) }
            add(act.settingRow(R.drawable.ic_close, Brand.YELLOW, "Cancel all active", "Stops everything in progress", null) {
                dialog.dismiss()
                val ids = items.filter { isActive(it.status) }.map { it.id }
                if (ids.isNotEmpty()) dm.remove(*ids.toLongArray())
                toast("Cancelled ${ids.size}")
                poll()
            })
            add(act.settingRow(R.drawable.ic_trash, Brand.RED, "Delete all completed", "Also deletes the files", null) {
                dialog.dismiss()
                val ids = items.filter { it.status == DownloadManager.STATUS_SUCCESSFUL }.map { it.id }
                if (ids.isNotEmpty()) dm.remove(*ids.toLongArray())
                toast("Deleted ${ids.size}")
                poll()
            })
            add(act.settingRow(R.drawable.ic_open, Brand.GREEN, "System Downloads", "Open Android's Downloads app", null) {
                dialog.dismiss()
                try {
                    startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                } catch (e: Exception) {
                    toast("Not available on this phone")
                }
            })
        }
    }
}

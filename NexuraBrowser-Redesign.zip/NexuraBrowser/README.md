# Nexura Browser

Starter Android browser project built with Kotlin + Android WebView.

## Included in this starter
- Normal browser home and URL/search bar
- First-launch private key setup; Admin prompts for that key to open a separate private session
- Private WebView clears history/cache/form data on entry, pause, and exit
- Android DownloadManager downloads with system notifications
- Basic built-in request blocking (starter domain/path filter)
- Modern UI: rounded cards, floating bottom nav, vector icons, gradient progress bar, animated bottom sheets
- 4-color brand theme (red, yellow, green, purple) with a day/night switch and a pickable accent color
- New app logo (adaptive + themed icon)
- Custom DNS-over-HTTPS URL preference field (not yet a network-wide WebView resolver)
- Bottom navigation: Home, Admin, Settings, Info
- GitHub Actions workflow builds a debug APK and uploads it as an artifact

## Build on GitHub
1. Create a GitHub repository named `NexuraBrowser`.
2. Upload the contents of this ZIP to the repository root (including the `.github` folder).
3. Open **Actions** and run **Build Nexura Browser APK** or push a commit.
4. Open the completed workflow run and download the `Nexura-Browser-debug` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

## Build locally
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```

## Important limitations
- This is an initial starter, not a production-grade replacement for Chrome.
- The private mode prevents the app from intentionally keeping browsing history and clears the WebView cache on session changes, but cannot erase DNS/network logs, website-side records, screenshots, downloads, or traces outside the app.
- Private key is stored as a SHA-256 hash in app preferences. It is an app-level gate, not a secure vault against someone with device/root/backup access.
- Android DownloadManager supports background downloads, but site authentication, expiring links, DRM, app force-stop, reboot, and OS restrictions may affect them. Download only content you are authorized to download.
- The DNS-over-HTTPS setting is stored as a preference only. It does not transparently reroute WebView networking yet; Android's Private DNS setting is separate.
- Ad filtering is a basic request filter and can miss ads or break some sites. A full filter-list engine and per-site controls should be added before release.
- `targetSdk 35` and newer Android versions may require notification runtime permission handling and additional testing.

- Live Downloads screen: per-file percent, speed, time left, progress bar, filter chips (Images, Videos, Audio, APK, Docs, Archives), search, sort, open/share/copy link/delete, retry failed

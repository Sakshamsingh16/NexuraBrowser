package in.nexura.browser

import android.app.*
import android.os.*
import android.graphics.Color
import android.view.*
import android.view.inputmethod.EditorInfo
import android.content.*
import android.net.Uri
import android.webkit.*
import android.widget.*
import android.text.InputType
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private lateinit var status: TextView
    private var web: WebView? = null
    private var privateMode = false
    private var adminUnlocked = false
    private var dark = true
    private var accent = "#E53935"
    private var adBlock = true
    private var customDns = ""
    private val prefs by lazy { getSharedPreferences("nexura_settings", MODE_PRIVATE) }
    private val blocked = listOf("doubleclick.net", "googlesyndication.com", "adservice.google.", "adnxs.com", "adsystem.com", "adserver", "/ads/", "analytics.")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.contains("key_hash")) showCreateKey() else showBrowser()
    }

    private fun showCreateKey() {
        val box = LinearLayout(this).apply { orientation = 1; setPadding(28, 80, 28, 24); setBackgroundColor(Color.rgb(18,20,28)) }
        box.addView(TextView(this).apply { text = "Welcome to Nexura Browser\nCreate your private-mode key"; textSize = 24f; setTextColor(Color.WHITE) })
        val key = EditText(this).apply { hint = "Create a key (minimum 4 characters)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        box.addView(key)
        box.addView(Button(this).apply { text = "Save key"; setOnClickListener {
            val value = key.text.toString()
            if (value.length < 4) { key.error = "Use at least 4 characters"; return@setOnClickListener }
            prefs.edit().putString("key_hash", hash(value)).apply()
            showBrowser()
        }})
        setContentView(box)
    }

    private fun showBrowser() {
        root = LinearLayout(this).apply { orientation = 1 }
        val top = LinearLayout(this).apply { orientation = 1; setPadding(12, 8, 12, 4) }
        top.addView(TextView(this).apply { text = "NEXURA"; textSize = 20f; setTextColor(Color.parseColor(accent)); setPadding(4, 4, 4, 8) })
        address = EditText(this).apply {
            hint = "Search or enter website"; singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_NULL) { navigate(text.toString()); true } else false }
        }
        top.addView(address)
        val actions = LinearLayout(this)
        actions.addView(Button(this).apply { text = "←"; setOnClickListener { web?.goBack() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply { text = "→"; setOnClickListener { web?.goForward() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply { text = "↻"; setOnClickListener { web?.reload() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply { text = "＋"; setOnClickListener { home() } }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actions)
        root.addView(top)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "Ready"; setPadding(12, 4, 12, 4); textSize = 12f }
        root.addView(status)
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(2, 2, 2, 8) }
        listOf("Home", "Admin", "Settings", "Info").forEach { item ->
            nav.addView(Button(this).apply { text = item; isAllCaps = false; setOnClickListener {
                when(item) { "Home" -> home(); "Admin" -> adminGate(); "Settings" -> settings(); else -> info() }
            } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        applyTheme()
        setContentView(root)
        home()
    }

    private fun home() {
        privateMode = false
        web?.destroy()
        web = null
        content.removeAllViews()
        val panel = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24) }
        panel.addView(TextView(this).apply { text = "Nexura Browser"; textSize = 28f; setTextColor(Color.parseColor(accent)) })
        panel.addView(TextView(this).apply { text = "Fast • Private • Your web"; textSize = 14f; setPadding(0, 8, 0, 24) })
        val search = EditText(this).apply { hint = "Search the web or enter URL"; singleLine = true; imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> navigate(text.toString()); true } }
        panel.addView(search, LinearLayout.LayoutParams(-1, -2))
        val go = Button(this).apply { text = "Search"; setOnClickListener { navigate(search.text.toString()) } }
        panel.addView(go)
        panel.addView(Button(this).apply { text = "Downloads"; setOnClickListener { showDownloads() } })
        content.addView(panel)
        status.text = "Normal browsing"
    }

    private fun navigate(raw: String) {
        var url = raw.trim()
        if (url.isBlank()) return
        if (!url.contains("://")) {
            url = if (url.contains(".") && !url.contains(" ")) "https://$url" else "https://www.google.com/search?q=" + Uri.encode(url)
        }
        if (url.startsWith("http://")) url = url.replaceFirst("http://", "https://")
        if (web == null) createWebView()
        address.setText(url)
        web?.loadUrl(url)
    }

    private fun createWebView() {
        content.removeAllViews()
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.loadsImagesAutomatically = true
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.settings.javaScriptCanOpenWindowsAutomatically = false
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = false
        if (privateMode) {
            w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            w.clearCache(true); w.clearHistory(); w.clearFormData()
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                return if (!u.startsWith("https://") && !u.startsWith("http://")) true else false
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock && blocked.any { request?.url?.host?.contains(it, true) == true || request?.url?.path?.contains(it, true) == true }) {
                    return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", mapOf("Access-Control-Allow-Origin" to "*"), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                address.setText(url ?: "")
                status.text = if (privateMode) "Private session • History not saved by app" else "Browsing"
            }
        }
        w.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ -> enqueueDownload(url, userAgent, contentDisposition, mimeType) }
        content.addView(w, FrameLayout.LayoutParams(-1, -1))
    }

    private fun adminGate() {
        val input = EditText(this).apply { hint = "Enter your private key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Admin • Private Browser").setMessage("Enter the key created on first launch.")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Unlock") { _, _ ->
                if (hash(input.text.toString()) == prefs.getString("key_hash", "")) {
                    adminUnlocked = true; openPrivate()
                } else Toast.makeText(this, "Incorrect key", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun openPrivate() {
        privateMode = true
        web?.apply { stopLoading(); clearHistory(); clearCache(true); clearFormData(); destroy() }
        web = null
        createWebView()
        status.text = "Private session • history disabled"
        address.setText("")
    }

    private fun settings() {
        val options = arrayOf("Toggle Day/Night mode", "Accent: Red", "Accent: Yellow", "Accent: Green", "Toggle built-in ad blocker", "Set custom DNS-over-HTTPS URL", "Clear normal browser data", "Change private key")
        AlertDialog.Builder(this).setTitle("Settings").setItems(options) { _, which ->
            when(which) {
                0 -> { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); applyTheme() }
                1 -> setAccent("#E53935")
                2 -> setAccent("#F9A825")
                3 -> setAccent("#2E7D32")
                4 -> { adBlock = !adBlock; Toast.makeText(this, "Ad blocker: $adBlock", Toast.LENGTH_SHORT).show(); web?.reload() }
                5 -> dnsDialog()
                6 -> { web?.clearHistory(); web?.clearCache(true); web?.clearFormData(); Toast.makeText(this, "Browser data cleared", Toast.LENGTH_SHORT).show() }
                7 -> changeKey()
            }
        }.show()
    }

    private fun dnsDialog() {
        val e = EditText(this).apply { hint = "https://dns.google/dns-query"; setText(customDns) }
        AlertDialog.Builder(this).setTitle("Custom DNS-over-HTTPS").setMessage("Saved as a preference for future network integration. WebView does not route all traffic through custom DoH automatically.")
            .setView(e).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                customDns = e.text.toString().trim(); prefs.edit().putString("custom_dns", customDns).apply()
                Toast.makeText(this, "DNS preference saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun changeKey() {
        val e = EditText(this).apply { hint = "New key (minimum 4 characters)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Change private key").setView(e).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            if (e.text.length >= 4) prefs.edit().putString("key_hash", hash(e.text.toString())).apply()
            else Toast.makeText(this, "Key must be at least 4 characters", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showDownloads() {
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val cursor = dm.query(DownloadManager.Query())
        val lines = StringBuilder()
        if (cursor != null) {
            while(cursor.moveToNext()) {
                val title = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE))
                val statusCol = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                lines.append("• ").append(title).append(" — ").append(when(statusCol) { 8 -> "Complete"; 16 -> "Failed"; 2 -> "Running"; 4 -> "Paused"; else -> "Queued" }).append('\n')
            }
            cursor.close()
        }
        AlertDialog.Builder(this).setTitle("Downloads").setMessage(if(lines.isEmpty()) "No downloads yet." else lines.toString()).setPositiveButton("OK", null).show()
    }

    private fun enqueueDownload(url: String, userAgent: String, disposition: String, mime: String) {
        try {
            val name = URLUtil.guessFileName(url, disposition, mime)
            val req = DownloadManager.Request(Uri.parse(url)).setTitle(name).setDescription("Downloading with Nexura Browser")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            if (mime.isNotBlank()) req.setMimeType(mime)
            if (userAgent.isNotBlank()) req.addRequestHeader("User-Agent", userAgent)
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Download started: $name", Toast.LENGTH_SHORT).show()
        } catch(e: Exception) { Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun info() {
        AlertDialog.Builder(this).setTitle("About Nexura Browser").setMessage("Nexura Browser 1.0.0\nKotlin • Android WebView\n\nPrivate browsing reduces local traces but cannot hide activity from websites, network providers, or downloaded files. Downloads depend on website access and Android background policies.").setPositiveButton("OK", null).show()
    }

    private fun setAccent(color: String) { accent = color; prefs.edit().putString("accent", color).apply(); applyTheme() }
    private fun applyTheme() {
        if (!::root.isInitialized) return
        dark = prefs.getBoolean("dark", dark)
        accent = prefs.getString("accent", accent) ?: accent
        val bg = if (dark) Color.rgb(18,20,28) else Color.WHITE
        val fg = if (dark) Color.WHITE else Color.BLACK
        root.setBackgroundColor(bg); root.setTextColorCompat(fg)
    }
    private fun LinearLayout.setTextColorCompat(color: Int) {
        for(i in 0 until childCount) {
            val v = getChildAt(i)
            if (v is TextView) v.setTextColor(color)
            if (v is LinearLayout) v.setTextColorCompat(color)
        }
    }
    private fun hash(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    override fun onPause() {
        if (privateMode) {
            web?.apply { stopLoading(); clearHistory(); clearCache(true); clearFormData() }
        }
        super.onPause()
    }
    override fun onDestroy() {
        if (privateMode) web?.apply { loadUrl("about:blank"); clearHistory(); clearCache(true); clearFormData(); destroy() }
        super.onDestroy()
    }
    override fun onBackPressed() {
        if (web?.canGoBack() == true) web?.goBack() else home()
    }
}

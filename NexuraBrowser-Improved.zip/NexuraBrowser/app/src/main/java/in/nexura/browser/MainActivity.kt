package `in`.nexura.browser

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: View
    private var loadingOverlay: LinearLayout? = null
    private lateinit var privateChip: TextView
    private lateinit var backBtn: FrameLayout
    private lateinit var fwdBtn: FrameLayout
    private lateinit var pal: Palette
    private val navItems = mutableListOf<LinearLayout>()
    private var web: WebView? = null
    private var privateMode = false
    private var adminUnlocked = false
    private var dark = true
    private var accent = Brand.PURPLE
    private var adBlock = true
    private var customDns = ""
    private var askedNotif = false
    private val prefs by lazy { getSharedPreferences("nexura_settings", MODE_PRIVATE) }
    private val blocked = listOf("doubleclick.net", "googlesyndication.com", "adservice.google.", "adnxs.com", "adsystem.com", "adserver", "/ads/", "analytics.")

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", true)
        accent = loadAccent()
        adBlock = prefs.getBoolean("ad_block", true)
        customDns = prefs.getString("custom_dns", "") ?: ""
        pal = Palette(dark, accent)
        setupEdgeToEdge()
        if (!prefs.contains("key_hash")) showCreateKey() else showBrowser()
    }

    private fun loadAccent(): Int = when (prefs.getString("accent", "purple")) {
        "red", "#E53935" -> Brand.RED
        "yellow", "#F9A825" -> Brand.YELLOW
        "green", "#2E7D32" -> Brand.GREEN
        else -> Brand.PURPLE
    }

    override fun onPause() {
        if (privateMode) {
            web?.apply { stopLoading(); clearHistory(); clearCache(true); clearFormData() }
        }
        super.onPause()
    }

    override fun onDestroy() {
        if (privateMode) web?.apply { loadUrl("about:blank"); clearHistory(); clearCache(true); clearFormData(); destroy() }
        super.onDestroy()
    }

    override fun onBackPressed() {
        val w = web
        when {
            w != null && w.canGoBack() -> w.goBack()
            w != null -> { closeWeb(); showLanding() }
            privateMode -> home()
            else -> super.onBackPressed()
        }
    }

    // ───────────────────────── window / insets ─────────────────────────

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    }

    @Suppress("DEPRECATION")
    private fun applyBars() {
        val light = !dark
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (light) mask else 0, mask)
        } else {
            val bits = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            var f = window.decorView.systemUiVisibility
            f = if (light) f or bits else f and bits.inv()
            window.decorView.systemUiVisibility = f
        }
    }

    @Suppress("DEPRECATION")
    private fun applyInsets(v: View) {
        v.setOnApplyWindowInsetsListener { view, insets ->
            val l: Int
            val t: Int
            val r: Int
            val b: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val sb = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                l = sb.left; t = sb.top; r = sb.right; b = maxOf(sb.bottom, ime.bottom)
            } else {
                l = insets.systemWindowInsetLeft; t = insets.systemWindowInsetTop
                r = insets.systemWindowInsetRight; b = insets.systemWindowInsetBottom
            }
            view.setPadding(l, t, r, b)
            insets
        }
        v.requestApplyInsets()
    }

    // ───────────────────────── first launch: create key ─────────────────────────

    private fun showCreateKey() {
        pal = Palette(dark, accent)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(pal.bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(24), dp(32), dp(24), dp(32))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        col.addView(logo(), lp(dp(96), dp(96)))
        val title = label("Nexura Browser", 32f, pal.text, 2)
        title.gradientText(Brand.ALL)
        col.addView(title, lp(WRAP, WRAP).apply { topMargin = dp(18) })
        col.addView(label("Fast • Private • Your web", 14f, pal.textSub), lp(WRAP, WRAP).apply { topMargin = dp(8) })

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(pal.surface, 28f, pal.outline, 1)
        card.setPadding(dp(20), dp(22), dp(20), dp(20))
        card.addView(label("Create your private key", 18f, pal.text, 2))
        val sub = label("This key unlocks Admin, your separate private browsing session.", 13f, pal.textSub)
        sub.setLineSpacing(0f, 1.15f)
        sub.setPadding(0, dp(6), 0, dp(16))
        card.addView(sub)
        val (field, input) = inputField("Minimum 4 characters", R.drawable.ic_key, true)
        card.addView(field, lp(MATCH, WRAP))
        val err = label("", 12f, Brand.RED, 1)
        err.visibility = View.GONE
        err.setPadding(dp(6), dp(8), 0, 0)
        card.addView(err)
        val save = pillButton("Save & continue", accent, pal.onAccent, withAlpha(pal.onAccent, 0.2f)) {
            val value = input.text.toString()
            if (value.length < 4) {
                err.text = "Use at least 4 characters"
                err.visibility = View.VISIBLE
            } else {
                prefs.edit().putString("key_hash", hash(value)).apply()
                showBrowser()
            }
        }
        card.addView(save, lp(MATCH, dp(52)).apply { topMargin = dp(18) })
        col.addView(card, lp(MATCH, WRAP).apply { topMargin = dp(36) })
        col.addView(label("You can change the key anytime in Settings.", 12f, pal.textSub), lp(WRAP, WRAP).apply { topMargin = dp(18) })

        setContentView(scroll)
        applyInsets(scroll)
        applyBars()
    }

    // ───────────────────────── main browser shell ─────────────────────────

    private fun showBrowser() {
        pal = Palette(dark, accent)
        val oldWeb = web
        (oldWeb?.parent as? ViewGroup)?.removeView(oldWeb)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)
        buildTopBar()
        root.addView(topBar, lp(MATCH, WRAP))
        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))
        root.addView(buildNav(), lp(MATCH, WRAP))

        setContentView(root)
        applyInsets(root)
        applyBars()

        if (oldWeb != null) {
            content.addView(oldWeb, FrameLayout.LayoutParams(MATCH, MATCH))
            topBar.visibility = View.VISIBLE
            address.setText(oldWeb.url ?: "")
            privateChip.visibility = if (privateMode) View.VISIBLE else View.GONE
            updateNav()
            updateNavButtons()
        } else {
            showLanding()
        }

        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    private fun buildTopBar() {
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.visibility = View.GONE
        val rip = withAlpha(pal.text, 0.12f)

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(8), dp(8))
        backBtn = iconButton(R.drawable.ic_back, pal.text, rip) { web?.goBack() }
        fwdBtn = iconButton(R.drawable.ic_forward, pal.text, rip) { web?.goForward() }
        row.addView(backBtn)
        row.addView(fwdBtn)

        val edge = if (privateMode) Brand.PURPLE else pal.outline
        val pill = LinearLayout(this)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = rounded(pal.surface, 24f, edge, 1)
        pill.setPadding(dp(14), 0, dp(6), 0)
        pill.addView(iconView(R.drawable.ic_lock, if (privateMode) Brand.PURPLE else Brand.GREEN), lp(dp(16), dp(16)))

        address = EditText(this)
        address.hint = "Search or enter website"
        address.background = null
        address.isSingleLine = true
        address.textSize = 14f
        address.setTextColor(pal.text)
        address.setHintTextColor(pal.textSub)
        address.setPadding(dp(10), 0, dp(6), 0)
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.setSelectAllOnFocus(true)
        address.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_NULL) {
                navigate(address.text.toString())
                hideKeyboard(address)
                true
            } else false
        }
        pill.addView(address, lp(0, MATCH, 1f))

        privateChip = label("PRIVATE", 10f, Brand.PURPLE, 2)
        privateChip.setPadding(dp(8), dp(4), dp(8), dp(4))
        privateChip.background = rounded(withAlpha(Brand.PURPLE, 0.18f), 10f)
        privateChip.visibility = if (privateMode) View.VISIBLE else View.GONE
        pill.addView(privateChip, lp(WRAP, WRAP).apply { rightMargin = dp(6) })

        row.addView(pill, lp(0, dp(46), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        row.addView(iconButton(R.drawable.ic_check, pal.text, rip) { saveBookmark() })
        row.addView(iconButton(R.drawable.ic_refresh, pal.text, rip) { web?.reload() })
        topBar.addView(row, lp(MATCH, WRAP))

        val bar = FrameLayout(this)
        progress = View(this)
        progress.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, Brand.ALL)
        progress.pivotX = 0f
        progress.scaleX = 0f
        progress.alpha = 0f
        bar.addView(progress, FrameLayout.LayoutParams(MATCH, MATCH))
        topBar.addView(bar, lp(MATCH, dp(3)))
    }

    private fun buildNav(): View {
        navItems.clear()
        val holder = FrameLayout(this)
        holder.setPadding(dp(14), dp(4), dp(14), dp(12))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER
        bar.setPadding(dp(6), dp(6), dp(6), dp(6))
        bar.background = rounded(pal.surface, 30f, pal.outline, 1)
        bar.elevation = dpf(if (dark) 0f else 6f)
        val names = listOf("Home", "Admin", "Settings", "Info")
        val icons = listOf(R.drawable.ic_home, R.drawable.ic_shield, R.drawable.ic_settings, R.drawable.ic_info)
        for (i in names.indices) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.addView(iconView(icons[i], pal.textSub), lp(dp(22), dp(22)))
            item.addView(label(names[i], 11f, pal.textSub, 1), lp(WRAP, WRAP).apply { topMargin = dp(4) })
            item.isClickable = true
            item.setOnClickListener {
                when (i) {
                    0 -> home()
                    1 -> adminGate()
                    2 -> settings()
                    else -> info()
                }
            }
            bar.addView(item, lp(0, dp(58), 1f).apply { if (i > 0) leftMargin = dp(4) })
            navItems.add(item)
        }
        holder.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP))
        return holder
    }

    private fun updateNav() {
        val sel = if (privateMode) 1 else 0
        navItems.forEachIndexed { i, item ->
            val on = i == sel
            val c = if (on) accent else pal.textSub
            item.background = ripple(if (on) withAlpha(accent, 0.16f) else Color.TRANSPARENT, 24f, withAlpha(accent, 0.2f))
            (item.getChildAt(0) as ImageView).setColorFilter(c)
            (item.getChildAt(1) as TextView).setTextColor(c)
        }
    }

    private fun updateNavButtons() {
        backBtn.alpha = if (web?.canGoBack() == true) 1f else 0.35f
        fwdBtn.alpha = if (web?.canGoForward() == true) 1f else 0.35f
    }

    private fun showProgress(p: Int) {
        progress.animate().cancel()
        if (p < 100) {
            progress.alpha = 1f
            progress.animate().scaleX(p / 100f).setDuration(180).start()
        } else {
            progress.animate().scaleX(1f).setDuration(150).withEndAction {
                progress.animate().alpha(0f).setDuration(250).withEndAction { progress.scaleX = 0f }.start()
            }.start()
        }
    }

    // ───────────────────────── landing (home / private home) ─────────────────────────

    private fun home() {
        if (privateMode) web?.apply { stopLoading(); clearHistory(); clearCache(true); clearFormData() }
        closeWeb()
        privateMode = false
        showLanding()
    }

    private fun closeWeb() {
        val w = web ?: return
        web = null
        content.removeAllViews()
        w.stopLoading()
        w.destroy()
    }

    private fun showLanding() {
        content.removeAllViews()
        topBar.visibility = View.GONE
        content.addView(buildLanding(), FrameLayout.LayoutParams(MATCH, MATCH))
        updateNav()
    }

    private fun buildLanding(): View {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(24), dp(24), dp(24), dp(24))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        val c = if (privateMode) Brand.PURPLE else accent
        val onC = if (privateMode) Color.WHITE else pal.onAccent

        if (privateMode) col.addView(badge(R.drawable.ic_shield, Brand.PURPLE, 96), lp(dp(96), dp(96)))
        else col.addView(logo(), lp(dp(96), dp(96)))

        val title = label(if (privateMode) "Private" else "Nexura", 40f, pal.text, 2)
        title.gradientText(if (privateMode) intArrayOf(Brand.PURPLE, Brand.RED) else Brand.ALL)
        col.addView(title, lp(WRAP, WRAP).apply { topMargin = dp(18) })
        col.addView(
            label(if (privateMode) "History isn't saved by the app" else "Fast • Private • Your web", 14f, pal.textSub),
            lp(WRAP, WRAP).apply { topMargin = dp(8) }
        )

        // search bar
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = rounded(pal.surface, 30f, if (privateMode) Brand.PURPLE else pal.outline, 1)
        bar.elevation = dpf(if (dark) 0f else 4f)
        bar.setPadding(dp(18), 0, dp(8), 0)
        bar.addView(iconView(R.drawable.ic_search, pal.textSub), lp(dp(22), dp(22)))
        val et = EditText(this)
        et.hint = "Search the web or enter URL"
        et.background = null
        et.isSingleLine = true
        et.textSize = 15f
        et.setTextColor(pal.text)
        et.setHintTextColor(pal.textSub)
        et.setPadding(dp(12), 0, dp(8), 0)
        et.imeOptions = EditorInfo.IME_ACTION_GO
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        et.setOnEditorActionListener { _, _, _ ->
            navigate(et.text.toString())
            hideKeyboard(et)
            true
        }
        bar.addView(et, lp(0, MATCH, 1f))
        bar.addView(iconButton(R.drawable.ic_arrow_go, onC, withAlpha(onC, 0.2f), fill = c, sizeDp = 44, iconDp = 22) {
            navigate(et.text.toString())
            hideKeyboard(et)
        })
        col.addView(bar, lp(MATCH, dp(60)).apply { topMargin = dp(28) })

        if (privateMode) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER
            val chips = listOf("No history" to Brand.RED, "No form data" to Brand.YELLOW, "Cache cleared" to Brand.GREEN)
            chips.forEachIndexed { i, (t, color) ->
                val chip = label(t, 11f, deepen(color), 1)
                chip.setPadding(dp(10), dp(7), dp(10), dp(7))
                chip.background = rounded(withAlpha(color, 0.16f), 20f)
                row.addView(chip, lp(WRAP, WRAP).apply { if (i > 0) leftMargin = dp(8) })
            }
            col.addView(row, lp(WRAP, WRAP).apply { topMargin = dp(26) })
        } else {
            val head = label("QUICK ACCESS", 11f, pal.textSub, 2)
            head.letterSpacing = 0.12f
            col.addView(head, lp(MATCH, WRAP).apply { topMargin = dp(32); bottomMargin = dp(14) })
            val links = listOf(
                Pair("Google", "G") to "https://www.google.com",
                Pair("YouTube", "Y") to "https://www.youtube.com",
                Pair("Wikipedia", "W") to "https://www.wikipedia.org",
                Pair("GitHub", "Gh") to "https://github.com",
                Pair("Reddit", "R") to "https://www.reddit.com",
                Pair("News", "N") to "https://news.google.com",
                Pair("Maps", "M") to "https://maps.google.com"
            )
            for (r in 0..1) {
                val row = LinearLayout(this)
                for (i in 0..3) {
                    val idx = r * 4 + i
                    val color = Brand.ALL[idx % 4]
                    val cell = if (idx < links.size) {
                        val (names, url) = links[idx]
                        quickTile(names.first, names.second, 0, color) { navigate(url) }
                    } else {
                        quickTile("Downloads", null, R.drawable.ic_download, color) { showDownloads() }
                    }
                    row.addView(cell, lp(0, WRAP, 1f))
                }
                col.addView(row, lp(MATCH, WRAP).apply { topMargin = if (r == 0) 0 else dp(18) })
            }
            val saved = prefs.getStringSet("bookmarks", emptySet())?.toList().orEmpty()
            if (saved.isNotEmpty()) {
                col.addView(label("SAVED BOOKMARKS", 11f, pal.textSub, 2), lp(MATCH, WRAP).apply { topMargin = dp(28); bottomMargin = dp(10) })
                saved.forEach { savedUrl ->
                    val row = LinearLayout(this)
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.background = rounded(pal.surface, 16f, pal.outline, 1)
                    row.setPadding(dp(14), dp(12), dp(14), dp(12))
                    row.addView(iconView(R.drawable.ic_globe, accent), lp(dp(20), dp(20)))
                    val title = label(Uri.parse(savedUrl).host ?: savedUrl, 13f, pal.text, 1)
                    row.addView(title, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
                    row.setOnClickListener { navigate(savedUrl) }
                    row.isClickable = true
                    col.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(7) })
                }
            }
        }
        return scroll
    }

    private fun saveBookmark() {
        val url = web?.url
        if (url.isNullOrBlank() || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Open a website first", Toast.LENGTH_SHORT).show(); return
        }
        val saved = (prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()).toMutableSet()
        saved.add(url)
        prefs.edit().putStringSet("bookmarks", saved).apply()
        Toast.makeText(this, "Saved to Home bookmarks", Toast.LENGTH_SHORT).show()
    }

    private fun quickTile(name: String, glyph: String?, iconRes: Int, color: Int, onClick: () -> Unit): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        val tile = FrameLayout(this)
        tile.background = ripple(withAlpha(color, 0.16f), 20f, withAlpha(color, 0.3f), withAlpha(color, 0.35f), 1)
        if (glyph != null) {
            tile.addView(label(glyph, 20f, deepen(color), 2), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        } else {
            tile.addView(iconView(iconRes, deepen(color)), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        tile.isClickable = true
        tile.setOnClickListener { onClick() }
        cell.addView(tile, lp(dp(58), dp(58)))
        val tv = label(name, 11f, pal.textSub, 1)
        tv.setPadding(0, dp(8), 0, 0)
        cell.addView(tv)
        return cell
    }

    // ───────────────────────── browsing ─────────────────────────

    private fun navigate(raw: String) {
        var url = raw.trim()
        if (url.isBlank()) return
        if (!url.contains("://")) {
            url = if (url.contains(".") && !url.contains(" ")) "https://$url" else "https://www.google.com/search?q=" + Uri.encode(url)
        }
        if (url.startsWith("http://")) url = url.replaceFirst("http://", "https://")
        if (web == null) createWebView()
        address.setText(url)
        web?.loadUrl(url)
    }

    private fun createWebView() {
        content.removeAllViews()
        val w = WebView(this)
        web = w
        w.setBackgroundColor(pal.bg)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.loadsImagesAutomatically = true
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.settings.javaScriptCanOpenWindowsAutomatically = false
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = false
        if (privateMode) {
            w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            w.clearCache(true); w.clearHistory(); w.clearFormData()
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                showProgress(newProgress)
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                return !u.startsWith("https://") && !u.startsWith("http://")
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock && blocked.any { request?.url?.host?.contains(it, true) == true || request?.url?.path?.contains(it, true) == true }) {
                    return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", mapOf("Access-Control-Allow-Origin" to "*"), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) address.setText(url)
                showLoadingOverlay()
                updateNavButtons()
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                address.setText(url ?: "")
                hideLoadingOverlay()
                updateNavButtons()
            }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) hideLoadingOverlay()
            }
        }
        w.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ -> enqueueDownload(url, userAgent, contentDisposition, mimeType) }
        content.addView(w, FrameLayout.LayoutParams(MATCH, MATCH))
        topBar.visibility = View.VISIBLE
        privateChip.visibility = if (privateMode) View.VISIBLE else View.GONE
        updateNav()
        updateNavButtons()
    }

    private fun showLoadingOverlay() {
        if (loadingOverlay?.parent != null) return
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER
        panel.setBackgroundColor(pal.bg)
        val spinner = ProgressBar(this)
        spinner.indeterminateTintList = ColorStateList.valueOf(accent)
        panel.addView(spinner, lp(dp(42), dp(42)))
        panel.addView(label("Loading page…", 14f, pal.textSub), lp(WRAP, WRAP).apply { topMargin = dp(14) })
        loadingOverlay = panel
        content.addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))
        panel.alpha = 0f
        panel.animate().alpha(1f).setDuration(160).start()
    }

    private fun hideLoadingOverlay() {
        loadingOverlay?.let { content.removeView(it) }
        loadingOverlay = null
    }

    // ───────────────────────── admin / private session ─────────────────────────

    private fun adminGate() {
        showSheet { body, dialog, _ ->
            sheetHeader(body, R.drawable.ic_shield, Brand.PURPLE, "Admin • Private browser", "Enter the key created on first launch.")
            val (field, input) = inputField("Private key", R.drawable.ic_key, true)
            body.addView(field, lp(MATCH, WRAP).apply { topMargin = dp(12) })
            val err = errorLabel(body)
            addButtons(body, dialog, "Unlock") {
                if (hash(input.text.toString()) == prefs.getString("key_hash", "")) {
                    adminUnlocked = true
                    dialog.dismiss()
                    openPrivate()
                } else {
                    err.text = "Incorrect key"
                    err.visibility = View.VISIBLE
                }
            }
            focusInput(dialog, input)
        }
    }

    private fun openPrivate() {
        web?.apply { stopLoading(); clearHistory(); clearCache(true); clearFormData() }
        closeWeb()
        privateMode = true
        showLanding()
    }

    // ───────────────────────── settings ─────────────────────────

    private fun settings() {
        showSheet { body, dialog, redraw ->
            sheetHeader(body, R.drawable.ic_settings, accent, "Settings", "Make Nexura yours")
            fun add(v: View) { body.addView(v, lp(MATCH, WRAP).apply { topMargin = dp(10) }) }

            val darkSwitch = themedSwitch(dark) { v ->
                dark = v
                prefs.edit().putBoolean("dark", v).apply()
                refreshTheme()
                body.post { redraw() }
            }
            add(settingRow(
                if (dark) R.drawable.ic_moon else R.drawable.ic_sun, Brand.PURPLE, "Dark mode",
                if (dark) "Night theme is on" else "Day theme is on", darkSwitch
            ) { darkSwitch.toggle() })

            // accent color picker
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = rounded(pal.surfaceHigh, 20f)
            card.setPadding(dp(12), dp(12), dp(12), dp(16))
            val head = LinearLayout(this)
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(badge(R.drawable.ic_drop, Brand.RED, 42), lp(dp(42), dp(42)))
            val ht = LinearLayout(this)
            ht.orientation = LinearLayout.VERTICAL
            ht.addView(label("Accent color", 15f, pal.text, 1))
            val hs = label("Buttons, highlights & navigation", 12f, pal.textSub)
            hs.setPadding(0, dp(2), 0, 0)
            ht.addView(hs)
            head.addView(ht, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
            card.addView(head, lp(MATCH, WRAP))
            val dots = LinearLayout(this)
            dots.gravity = Gravity.CENTER
            val options = listOf("red" to Brand.RED, "yellow" to Brand.YELLOW, "green" to Brand.GREEN, "purple" to Brand.PURPLE)
            options.forEach { (name, c) ->
                val dot = FrameLayout(this)
                dot.background = circle(c)
                if (c == accent) {
                    val tick = if (c == Brand.YELLOW || c == Brand.GREEN) Color.parseColor("#1A1730") else Color.WHITE
                    dot.addView(iconView(R.drawable.ic_check, tick), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                }
                dot.isClickable = true
                dot.setOnClickListener {
                    setAccent(name)
                    body.post { redraw() }
                }
                dots.addView(dot, lp(dp(40), dp(40)).apply { leftMargin = dp(12); rightMargin = dp(12) })
            }
            card.addView(dots, lp(MATCH, WRAP).apply { topMargin = dp(14) })
            add(card)

            val adSwitch = themedSwitch(adBlock) { v ->
                adBlock = v
                prefs.edit().putBoolean("ad_block", v).apply()
                web?.reload()
            }
            add(settingRow(R.drawable.ic_block, Brand.YELLOW, "Ad blocker", "Block ads & trackers", adSwitch) { adSwitch.toggle() })

            add(settingRow(
                R.drawable.ic_globe, Brand.GREEN, "DNS-over-HTTPS",
                if (customDns.isBlank()) "Not set" else customDns, iconView(R.drawable.ic_chevron, pal.textSub)
            ) { dialog.dismiss(); dnsSheet() })

            add(settingRow(R.drawable.ic_trash, Brand.RED, "Clear browsing data", "History, cache & form data", null) {
                web?.clearHistory(); web?.clearCache(true); web?.clearFormData()
                Toast.makeText(this, "Browser data cleared", Toast.LENGTH_SHORT).show()
            })

            add(settingRow(
                R.drawable.ic_key, Brand.PURPLE, "Change private key", "Update your Admin key",
                iconView(R.drawable.ic_chevron, pal.textSub)
            ) { dialog.dismiss(); changeKey() })
        }
    }

    private fun setAccent(name: String) {
        prefs.edit().putString("accent", name).apply()
        accent = loadAccent()
        refreshTheme()
    }

    private fun refreshTheme() {
        pal = Palette(dark, accent)
        showBrowser()
    }

    private fun dnsSheet() {
        showSheet { body, dialog, _ ->
            sheetHeader(body, R.drawable.ic_globe, Brand.GREEN, "Custom DNS-over-HTTPS", "Saved as a preference for future network integration. WebView does not route all traffic through custom DoH automatically.")
            val (field, input) = inputField("https://dns.google/dns-query", R.drawable.ic_globe, false)
            input.setText(customDns)
            body.addView(field, lp(MATCH, WRAP).apply { topMargin = dp(12) })
            addButtons(body, dialog, "Save") {
                customDns = input.text.toString().trim()
                prefs.edit().putString("custom_dns", customDns).apply()
                dialog.dismiss()
                Toast.makeText(this, "DNS preference saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun changeKey() {
        showSheet { body, dialog, _ ->
            sheetHeader(body, R.drawable.ic_key, Brand.PURPLE, "Change private key", "Choose a new key for Admin")
            val (field, input) = inputField("New key (minimum 4 characters)", R.drawable.ic_lock, true)
            body.addView(field, lp(MATCH, WRAP).apply { topMargin = dp(12) })
            val err = errorLabel(body)
            addButtons(body, dialog, "Save") {
                if (input.text.length >= 4) {
                    prefs.edit().putString("key_hash", hash(input.text.toString())).apply()
                    dialog.dismiss()
                    Toast.makeText(this, "Private key updated", Toast.LENGTH_SHORT).show()
                } else {
                    err.text = "Key must be at least 4 characters"
                    err.visibility = View.VISIBLE
                }
            }
            focusInput(dialog, input)
        }
    }

    // ───────────────────────── downloads & info ─────────────────────────

    private fun showDownloads() {
        val items = mutableListOf<Pair<String, Int>>()
        try {
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val cursor = dm.query(DownloadManager.Query().setFilterByStatus(DownloadManager.STATUS_PENDING or DownloadManager.STATUS_RUNNING or DownloadManager.STATUS_PAUSED or DownloadManager.STATUS_SUCCESSFUL or DownloadManager.STATUS_FAILED))
            if (cursor != null) {
                cursor.use {
                    val ti = it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                    val si = it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                    while (it.moveToNext() && items.size < 40) {
                        items.add((it.getString(ti) ?: "Download") to it.getInt(si))
                    }
                }
            }
        } catch (e: Exception) {
            // ignore, shows empty state
        }
        showSheet { body, _, _ ->
            sheetHeader(body, R.drawable.ic_download, Brand.GREEN, "Downloads", "Saved in your device's Downloads folder")
            body.addView(pillButton("Open Downloads folder", accent, pal.onAccent, withAlpha(pal.onAccent, 0.2f)) {
                try {
                    val intent = android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(this, "Open Files app → Downloads", Toast.LENGTH_LONG).show()
                }
            }, lp(MATCH, dp(48)).apply { topMargin = dp(10) })
            if (items.isEmpty()) {
                val empty = LinearLayout(this)
                empty.orientation = LinearLayout.VERTICAL
                empty.gravity = Gravity.CENTER
                empty.setPadding(0, dp(28), 0, dp(12))
                empty.addView(badge(R.drawable.ic_download, Brand.GREEN, 72), lp(dp(72), dp(72)))
                empty.addView(label("No downloads yet", 16f, pal.text, 2), lp(WRAP, WRAP).apply { topMargin = dp(14) })
                empty.addView(label("Files you download will show up here.", 13f, pal.textSub), lp(WRAP, WRAP).apply { topMargin = dp(4) })
                body.addView(empty, lp(MATCH, WRAP))
            } else {
                for ((name, status) in items) {
                    val (statusText, statusColor) = when (status) {
                        8 -> "Complete" to Brand.GREEN
                        16 -> "Failed" to Brand.RED
                        2 -> "Running" to Brand.YELLOW
                        4 -> "Paused" to Brand.PURPLE
                        else -> "Queued" to Brand.PURPLE
                    }
                    val row = LinearLayout(this)
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.background = rounded(pal.surfaceHigh, 18f)
                    row.setPadding(dp(14), dp(12), dp(12), dp(12))
                    val title = label(name, 14f, pal.text, 1)
                    title.maxLines = 1
                    title.ellipsize = TextUtils.TruncateAt.END
                    row.addView(title, lp(0, WRAP, 1f).apply { rightMargin = dp(10) })
                    val chip = label(statusText, 11f, deepen(statusColor), 1)
                    chip.setPadding(dp(10), dp(5), dp(10), dp(5))
                    chip.background = rounded(withAlpha(statusColor, 0.18f), 12f)
                    row.addView(chip, lp(WRAP, WRAP))
                    body.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(10) })
                }
            }
        }
    }

    private fun enqueueDownload(url: String, userAgent: String, disposition: String, mime: String) {
        try {
            val name = URLUtil.guessFileName(url, disposition, mime)
            val req = DownloadManager.Request(Uri.parse(url)).setTitle(name).setDescription("Downloading with Nexura Browser")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            if (mime.isNotBlank()) req.setMimeType(mime)
            if (userAgent.isNotBlank()) req.addRequestHeader("User-Agent", userAgent)
            val cookies = CookieManager.getInstance().getCookie(url)
            if (!cookies.isNullOrBlank()) req.addRequestHeader("Cookie", cookies)
            web?.url?.let { req.addRequestHeader("Referer", it) }
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Download started: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun info() {
        showSheet { body, dialog, _ ->
            val center = LinearLayout(this)
            center.orientation = LinearLayout.VERTICAL
            center.gravity = Gravity.CENTER_HORIZONTAL
            center.addView(logo(), lp(dp(84), dp(84)))
            center.addView(label("Nexura Browser", 22f, pal.text, 2), lp(WRAP, WRAP).apply { topMargin = dp(14) })
            val ver = label("Version 1.0.0", 12f, deepen(accent), 1)
            ver.setPadding(dp(12), dp(5), dp(12), dp(5))
            ver.background = rounded(withAlpha(accent, 0.16f), 14f)
            center.addView(ver, lp(WRAP, WRAP).apply { topMargin = dp(10) })
            val dots = LinearLayout(this)
            dots.gravity = Gravity.CENTER
            Brand.ALL.forEachIndexed { i, c ->
                dots.addView(View(this).apply { background = circle(c) }, lp(dp(10), dp(10)).apply { if (i > 0) leftMargin = dp(8) })
            }
            center.addView(dots, lp(WRAP, WRAP).apply { topMargin = dp(14) })
            body.addView(center, lp(MATCH, WRAP))

            val card = LinearLayout(this)
            card.background = rounded(pal.surfaceHigh, 20f)
            card.setPadding(dp(16), dp(14), dp(16), dp(14))
            val desc = label(
                "Kotlin • Android WebView\n\nPrivate browsing reduces local traces but cannot hide activity from websites, network providers, or downloaded files. Downloads depend on website access and Android background policies.",
                13f, pal.textSub
            )
            desc.setLineSpacing(0f, 1.2f)
            card.addView(desc)
            body.addView(card, lp(MATCH, WRAP).apply { topMargin = dp(20) })
            val legal = listOf(
                "Privacy Policy" to "Nexura stores settings and bookmarks locally on this device. Normal browsing may be visible to websites and your network provider. Downloads are saved to your device. Private mode reduces local session traces but does not make you anonymous; downloaded files remain on your device.",
                "Terms & Conditions" to "Use Nexura lawfully and respect website terms and copyright. You are responsible for files you download and websites you visit. Website availability, downloads and ad blocking depend on third-party services and Android system behavior. Features are provided as-is without a guarantee of uninterrupted service.",
                "Safety Warning" to "Never enter passwords or payment details on websites you do not trust. Download files only from trusted sources and scan unknown files. Ad blocking is not perfect. Private browsing does not hide activity from websites, internet providers, employers or network administrators."
            )
            legal.forEach { (title, text) ->
                body.addView(settingRow(R.drawable.ic_info, accent, title, "Read important information", iconView(R.drawable.ic_chevron, pal.textSub)) {
                    showSheet { legalBody, legalDialog, _ ->
                        sheetHeader(legalBody, R.drawable.ic_info, accent, title, "Nexura Browser • Version 1.0.0")
                        val txt = label(text, 14f, pal.textSub)
                        txt.setLineSpacing(0f, 1.2f)
                        legalBody.addView(txt, lp(MATCH, WRAP).apply { topMargin = dp(14) })
                        legalBody.addView(pillButton("Close", accent, pal.onAccent, withAlpha(pal.onAccent, 0.2f)) { legalDialog.dismiss() }, lp(MATCH, dp(48)).apply { topMargin = dp(18) })
                    }
                }, lp(MATCH, WRAP).apply { topMargin = dp(10) })
            }
            body.addView(
                pillButton("Got it", accent, pal.onAccent, withAlpha(pal.onAccent, 0.2f)) { dialog.dismiss() },
                lp(MATCH, dp(50)).apply { topMargin = dp(18) }
            )
        }
    }

    // ───────────────────────── reusable pieces ─────────────────────────

    private fun logo(): ImageView {
        val v = ImageView(this)
        v.setImageResource(R.drawable.ic_logo_tile)
        return v
    }

    private fun deepen(c: Int): Int =
        if (dark) c else Color.rgb((Color.red(c) * 0.7f).toInt(), (Color.green(c) * 0.7f).toInt(), (Color.blue(c) * 0.7f).toInt())

    private fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun focusInput(dialog: Dialog, input: EditText) {
        input.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun inputField(hint: String, iconRes: Int, password: Boolean): Pair<LinearLayout, EditText> {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = rounded(pal.surfaceHigh, 18f, pal.outline, 1)
        row.setPadding(dp(16), 0, dp(8), 0)
        row.addView(iconView(iconRes, pal.textSub), lp(dp(20), dp(20)))
        val et = EditText(this)
        et.hint = hint
        et.background = null
        et.isSingleLine = true
        et.textSize = 15f
        et.setTextColor(pal.text)
        et.setHintTextColor(pal.textSub)
        et.setPadding(dp(12), 0, dp(12), 0)
        et.inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        row.addView(et, lp(0, dp(52), 1f))
        return row to et
    }

    private fun errorLabel(body: LinearLayout): TextView {
        val err = label("", 12f, Brand.RED, 1)
        err.visibility = View.GONE
        err.setPadding(dp(6), dp(8), 0, 0)
        body.addView(err)
        return err
    }

    private fun addButtons(body: LinearLayout, dialog: Dialog, primary: String, onPrimary: () -> Unit) {
        val row = LinearLayout(this)
        row.addView(
            pillButton("Cancel", pal.surfaceHigh, pal.text, withAlpha(pal.text, 0.12f)) { dialog.dismiss() },
            lp(0, dp(50), 1f)
        )
        row.addView(
            pillButton(primary, accent, pal.onAccent, withAlpha(pal.onAccent, 0.2f)) { onPrimary() },
            lp(0, dp(50), 1.3f).apply { leftMargin = dp(10) }
        )
        body.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(18) })
    }

    private fun sheetHeader(body: LinearLayout, res: Int, color: Int, title: String, sub: String?) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(badge(res, color, 48), lp(dp(48), dp(48)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 20f, pal.text, 2))
        if (sub != null) {
            val s = label(sub, 13f, pal.textSub)
            s.setPadding(0, dp(4), 0, 0)
            col.addView(s)
        }
        row.addView(col, lp(0, WRAP, 1f).apply { leftMargin = dp(14) })
        body.addView(row, lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
    }

    private fun settingRow(
        iconRes: Int, color: Int, title: String, sub: String, trailing: View?, onClick: (() -> Unit)?
    ): LinearLayout {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(12), dp(12), dp(12))
        row.background = ripple(pal.surfaceHigh, 20f, withAlpha(color, 0.2f))
        row.addView(badge(iconRes, color, 42), lp(dp(42), dp(42)))
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        txt.addView(label(title, 15f, pal.text, 1))
        val s = label(sub, 12f, pal.textSub)
        s.setPadding(0, dp(2), 0, 0)
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        txt.addView(s)
        row.addView(txt, lp(0, WRAP, 1f).apply { leftMargin = dp(12); rightMargin = dp(8) })
        if (trailing != null) row.addView(trailing, lp(WRAP, WRAP))
        if (onClick != null) {
            row.isClickable = true
            row.setOnClickListener { onClick() }
        }
        return row
    }

    private fun themedSwitch(checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, pal.textSub))
        s.trackTintList = ColorStateList(states, intArrayOf(accent, pal.outline))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        return s
    }

    /** Animated bottom sheet. [render] can call the 3rd arg to re-draw itself (e.g. after a theme change). */
    private fun showSheet(render: (body: LinearLayout, dialog: Dialog, redraw: () -> Unit) -> Unit): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(wrap, FrameLayout.LayoutParams(MATCH, WRAP))

        lateinit var draw: () -> Unit
        draw = {
            wrap.removeAllViews()
            val r = dpf(28f)
            val bg = GradientDrawable()
            bg.setColor(pal.surface)
            bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            wrap.background = bg
            wrap.setPadding(dp(20), dp(10), dp(20), dp(28))
            val handle = View(this)
            handle.background = rounded(pal.outline, 3f)
            wrap.addView(handle, lp(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })
            render(wrap, d, draw)
        }
        draw()

        d.setContentView(scroll)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.6f)
        }
        d.setOnShowListener {
            wrap.translationY = dpf(80f)
            wrap.alpha = 0f
            wrap.animate().translationY(0f).alpha(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        }
        d.show()
        return d
    }

    private fun hash(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}

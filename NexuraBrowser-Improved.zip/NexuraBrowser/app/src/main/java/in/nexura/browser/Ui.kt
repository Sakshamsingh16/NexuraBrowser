package `in`.nexura.browser

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

/** The 4 brand colors of Nexura. */
object Brand {
    val RED: Int = Color.parseColor("#FF4D5E")
    val YELLOW: Int = Color.parseColor("#FFC53D")
    val GREEN: Int = Color.parseColor("#2ED47A")
    val PURPLE: Int = Color.parseColor("#8B5CF6")
    val ALL: IntArray = intArrayOf(RED, YELLOW, GREEN, PURPLE)
}

/** Surface colors for day / night + the chosen accent. */
class Palette(val dark: Boolean, val accent: Int) {
    val bg: Int = Color.parseColor(if (dark) "#0F0D1A" else "#F6F4FF")
    val surface: Int = Color.parseColor(if (dark) "#1A1730" else "#FFFFFF")
    val surfaceHigh: Int = Color.parseColor(if (dark) "#252044" else "#EEEAFB")
    val outline: Int = Color.parseColor(if (dark) "#2E2954" else "#E1DCF6")
    val text: Int = Color.parseColor(if (dark) "#F5F3FF" else "#1A1730")
    val textSub: Int = Color.parseColor(if (dark) "#A9A4CC" else "#6B6790")
    val onAccent: Int =
        if (accent == Brand.YELLOW || accent == Brand.GREEN) Color.parseColor("#1A1730") else Color.WHITE
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun withAlpha(color: Int, a: Float): Int =
    Color.argb((a * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

/** Rounded rectangle (use a big radius for a pill / circle). */
fun Context.rounded(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dpf(radiusDp)
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.circle(fill: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setShape(GradientDrawable.OVAL)
    g.setColor(fill)
    return g
}

fun Context.ripple(
    fill: Int, radiusDp: Float, rippleColor: Int, strokeColor: Int = 0, strokeDp: Int = 0
): Drawable {
    val content = rounded(fill, radiusDp, strokeColor, strokeDp)
    val mask = rounded(Color.BLACK, radiusDp)
    return RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask)
}

/** weight: 0 = regular, 1 = medium, 2 = bold */
fun Context.label(text: String, sizeSp: Float, color: Int, weight: Int = 0): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    t.includeFontPadding = false
    t.typeface = when (weight) {
        2 -> Typeface.DEFAULT_BOLD
        1 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> Typeface.DEFAULT
    }
    return t
}

fun Context.iconView(res: Int, tint: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    return v
}

/** Round icon button. The ImageView is child 0 so it can be re-tinted later. */
fun Context.iconButton(
    res: Int, tint: Int, rippleColor: Int, fill: Int = Color.TRANSPARENT,
    sizeDp: Int = 40, iconDp: Int = 22, onClick: () -> Unit
): FrameLayout {
    val f = FrameLayout(this)
    f.background = ripple(fill, 999f, rippleColor)
    f.addView(iconView(res, tint), FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER))
    f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    f.isClickable = true
    f.setOnClickListener { onClick() }
    return f
}

/** Colored circle with an icon inside (used in settings rows and sheet headers). */
fun Context.badge(res: Int, color: Int, sizeDp: Int): FrameLayout {
    val f = FrameLayout(this)
    f.background = circle(withAlpha(color, 0.18f))
    val inner = (sizeDp * 0.5f).toInt()
    f.addView(iconView(res, color), FrameLayout.LayoutParams(dp(inner), dp(inner), Gravity.CENTER))
    return f
}

fun Context.pillButton(
    text: String, fill: Int, textColor: Int, rippleColor: Int, onClick: () -> Unit
): TextView {
    val t = label(text, 15f, textColor, 2)
    t.gravity = Gravity.CENTER
    t.background = ripple(fill, 999f, rippleColor)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

/** Paints the text with the 4 brand colors. Call after text + size are set. */
fun TextView.gradientText(colors: IntArray) {
    val w = paint.measureText(text.toString())
    paint.shader = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.CLAMP)
    invalidate()
}
